###########################################################################
# Created by: Shuo Gu
# Email: shuogu@njust.edu.cn
# Paper: Two-View Fusion based Convolutional Neural Network for Urban Road Detection, 2019 IROS
# Copyright (c) 2019
###########################################################################

# TVFNet

import os
import time
import torch
import timeit
import pickle
import random
import numpy as np
import torch.nn as nn
from torch.utils import data
from torch.autograd import Variable
import torch.backends.cudnn as cudnn
import torchvision.transforms as transforms
from argparse import ArgumentParser
# user
from model import TVFNet  # network
from utils.modeltools import netParams2
from utils.loss import *  # loss function
from utils.convert_state import convert_state_dict
from dataset.kitti_road_tvf import KittiRoadDataset, KittiRoadValDataset  # dataset
from PIL import Image


def val(args, val_loader, model, criterion):
    # evaluation mode
    model.eval()
    epoch_loss = []
    epoch_loss_imagery = []
    epoch_loss_cam = []

    for i, batch in enumerate(val_loader):
        imagery_velo, imagery_pj, imagery_labels, cam_velo, cam_labels = batch
        imagery_velo = Variable(imagery_velo).cuda()
        imagery_velo = imagery_velo.detach()
        imagery_pj = Variable(imagery_pj.long()).cuda()
        imagery_pj = imagery_pj.detach()
        imagery_labels = Variable(imagery_labels.long()).cuda()
        imagery_labels = imagery_labels.detach()
        cam_velo = Variable(cam_velo).cuda()
        cam_velo = cam_velo.detach()
        cam_labels = Variable(cam_labels.long()).cuda()
        cam_labels = cam_labels.detach()

        imagery_output, cam_output = model(imagery_velo, imagery_pj, cam_velo)
        loss, loss_imagery, loss_cam = criterion(imagery_output, cam_output, imagery_labels, cam_labels)

        epoch_loss.append(loss.item())
        epoch_loss_imagery.append(loss_imagery.item())
        epoch_loss_cam.append(loss_cam.item())

    loss = sum(epoch_loss) / len(epoch_loss)
    loss_imagery = sum(epoch_loss_imagery) / len(epoch_loss)
    loss_cam = sum(epoch_loss_cam) / len(epoch_loss)

    return loss, loss_imagery, loss_cam

def adjust_learning_rate(args, cur_epoch, max_epoch, baselr):
    lr = baselr * pow((1 - 1.0 * cur_epoch / max_epoch), 0.9)
    return lr

def train(args, train_loader, model, criterion, optimizer, epoch):
    model.train()
    epoch_loss = []
    epoch_loss_imagery = []
    epoch_loss_cam = []

    total_batches = len(train_loader)
    print("=====> the number of iterations per epoch: ", total_batches)
    for iteration, batch in enumerate(train_loader, 0):
        optimizer.zero_grad()  # set the grad to zero

        lr = adjust_learning_rate(args, cur_epoch=epoch, max_epoch=args.max_epochs, baselr=args.lr)
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr

        imagery_velo, imagery_pj, imagery_labels, cam_velo, cam_labels = batch
        imagery_velo = Variable(imagery_velo).cuda()
        imagery_pj = Variable(imagery_pj.long()).cuda()
        imagery_labels = Variable(imagery_labels.long()).cuda()
        cam_velo = Variable(cam_velo).cuda()
        cam_labels = Variable(cam_labels.long()).cuda()

        imagery_output, cam_output = model(imagery_velo, imagery_pj, cam_velo)
        loss, loss_imagery, loss_cam = criterion(imagery_output, cam_output, imagery_labels, cam_labels)


        lambda2 = 1e-4
        l2_regularizaztion = torch.tensor(0.).cuda()
        for param in model.parameters():
            if param.dtype.is_floating_point:
                l2_regularizaztion += torch.norm(param, 2)
        loss = loss + l2_regularizaztion * lambda2

        loss.backward()
        optimizer.step()
        epoch_loss.append(loss.item())
        epoch_loss_imagery.append(loss_imagery.item())
        epoch_loss_cam.append(loss_cam.item())

    loss = sum(epoch_loss) / len(epoch_loss)
    loss_imagery = sum(epoch_loss_imagery) / len(epoch_loss)
    loss_cam = sum(epoch_loss_cam) / len(epoch_loss)

    return loss, loss_imagery, loss_cam, lr


def train_model(args):

    print(args)
    global network_type

    if args.cuda:
        print("=====> use gpu id: '{}'".format(args.gpus))
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus
        if not torch.cuda.is_available():
            raise Exception("No GPU found or Wrong gpu id, please run without --cuda")

    cudnn.enabled = True
    model = TVFNet.TVFNet()
    network_type = "TVFNet"
    print("=====> current architeture:  TVFNet")

    print("=====> computing network parameters")
    total_paramters = netParams2(model)
    print("the number of parameters: " + str(total_paramters))

    # define optimization criteria
    criteria = CrossEntropyLoss2d()

    if args.cuda:
        criteria = criteria.cuda()
        if torch.cuda.device_count() > 1:
            print("torch.cuda.device_count()=", torch.cuda.device_count())
            args.gpu_nums = torch.cuda.device_count()
            model = torch.nn.DataParallel(model).cuda()  # multi-card data parallel
        else:
            print("single GPU for training")
            model = model.cuda()  # 1-card data parallel

    args.savedir = (args.savedir + args.dataset + '/' + network_type + '_bs' + str(args.batch_size) +
                    'gpu' + '0/')
    if not os.path.exists(args.savedir):
        os.makedirs(args.savedir)

    trainLoader = data.DataLoader(
        KittiRoadDataset(args.data_dir),
        batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True, drop_last=True)
    valLoader = data.DataLoader(KittiRoadValDataset(args.data_dir),
                                batch_size=1, shuffle=True, num_workers=args.num_workers, pin_memory=True,
                                drop_last=True)

    start_epoch = 0
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            start_epoch = checkpoint['epoch']
            model.load_state_dict(checkpoint['model'])
            print("=====> loaded checkpoint '{}' (epoch {})".format(args.resume, checkpoint['epoch']))
        else:
            print("=====> no checkpoint found at '{}'".format(args.resume))

    model.train()
    cudnn.benchmark = True

    logFileLoc = args.savedir + args.logFile
    if os.path.isfile(logFileLoc):
        logger = open(logFileLoc, 'a')
    else:
        logger = open(logFileLoc, 'w')
        logger.write("Parameters: %s" % (str(total_paramters)))
        logger.write("\n%s\t\t%s\t\t%s\t\t%s\t\t%s\t\t%s\t\t" % ('Epoch', 'Loss(train)', 'Loss(val)', 'lr',
                                                                       'Imagery loss', 'Cam loss'))
    logger.flush()

    optimizer = torch.optim.Adam(model.parameters(), args.lr, (0.9, 0.999), eps=1e-08, weight_decay=1e-4)

    print('=====> beginning training')
    best_loss_val = 10
    for epoch in range(start_epoch, args.max_epochs):
        # training
        loss_train, loss_imagery, loss_cam, lr = train(args, trainLoader, model, criteria, optimizer, epoch)
        # validation
        if epoch % 1 == 0:
            loss_val,_,_ = val(args, valLoader, model, criteria)
            # record train information
            logger.write("\n%d\t\t%.4f\t\t%.4f\t\t%.7f\t\t%.4f\t\t%.4f" % (epoch, loss_train, loss_val, lr, loss_imagery, loss_cam))
            logger.flush()
            print("Epoch : " + str(epoch) + ' Details')
            print("\nEpoch No.: %d\tTrain Loss = %.4f\t Val Loss = %.4f\t lr= %.6f\tTrain Imagery Loss = %.4f"
                  "\tTrain Cam Loss = %.4f" % (epoch, loss_train, loss_val, lr, loss_imagery, loss_cam))

            if (loss_val<best_loss_val):
                best_loss_val = loss_val
                model_file_name = args.savedir + '/model_best.pth'
                state = {"epoch": epoch + 1, "model": model.state_dict()}
                torch.save(state, model_file_name)

        else:
            # record train information
            logger.write("\n%d\t\t%.4f\t\t%.7f" % (epoch, loss_train, lr))
            logger.flush()
            print("Epoch : " + str(epoch) + ' Details')
            print("\nEpoch No.: %d\tTrain Loss = %.4f\t lr= %.6f" % (epoch, loss_train, lr))

    logger.close()


if __name__ == '__main__':
    start = timeit.default_timer()
    parser = ArgumentParser()
    parser.add_argument('--model', default="TVFNet", help="model name: Two View Fusion based LiDAR Road Detection Network")
    parser.add_argument('--dataset', default="kitti_road")
    parser.add_argument('--data_dir', default="/test/Road/data_road", help='data directory')
    parser.add_argument('--max_epochs', type=int, default=100, help="the number of epochs")
    parser.add_argument('--num_workers', type=int, default=6, help=" the number of parallel threads")
    parser.add_argument('--batch_size', type=int, default=16, help="the batch size is set to 16 for 2 GPUs")
    parser.add_argument('--lr', type=float, default=1e-3, help="initial learning rate")
    parser.add_argument('--savedir', default="./checkpoint/", help="directory to save the model snapshot")
    parser.add_argument('--resume', type=str,
                        default="./checkpoint/kitti_road/TVFNet_bs4gpu0/model_best2.pth",
                        help="use this file to load last checkpoint for continuing training")
    parser.add_argument('--classes', type=int, default=2,
                        help="the number of classes in the dataset. 19 and 11 for cityscapes and camvid, respectively")
    parser.add_argument('--logFile', default="log.txt", help="storing the training and validation logs")
    parser.add_argument('--cuda', type=bool, default=True, help="running on CPU or GPU")
    parser.add_argument('--gpus', type=str, default="0", help="default GPU devices (0)")
    args = parser.parse_args()
    train_model(args)
    end = timeit.default_timer()
    print("training time:", 1.0 * (end - start) / 3600)