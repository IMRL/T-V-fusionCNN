###########################################################################
# Created by: Shuo Gu
# Email: shuogu@njust.edu.cn
# Paper: Two-View Fusion based Convolutional Neural Network for Urban Road Detection, 2019 IROS
# Copyright (c) 2019
###########################################################################

# TVFNet

import os
import time
import torch
import pickle
import random
import numpy as np
import torch.nn as nn
from PIL import Image
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
from argparse import ArgumentParser
# user
from model import TVFNet  # network
from utils.loss import *  # loss function
from utils.convert_state import convert_state_dict
from dataset.kitti_road_tvf import KittiRoadTestDataset  # dataset


from skimage import util
from skimage.measure import label, regionprops
def getLargestCC(segmentation):
    labels = label(segmentation, background=0.0)
    areas = np.bincount(labels.flat)
    areas[0] = 0

    largestCC = labels == np.argmax(areas)
    return largestCC

def test(args, test_loader, model):
    # evaluation mode
    model.eval()

    total_batches = len(test_loader)
    total_time = 0
    for i, batch in enumerate(test_loader):
        start_time = time.time()
        imagery_velo, imagery_pj, cam_velo, name, size = batch
        imagery_velo = Variable(imagery_velo).cuda()
        imagery_velo = imagery_velo.detach()
        imagery_pj = Variable(imagery_pj.long()).cuda()
        imagery_pj = imagery_pj.detach()
        cam_velo = Variable(cam_velo).cuda()
        cam_velo = cam_velo.detach()
        # -----------------------------------------------
        imagery_output, cam_output = model(imagery_velo, imagery_pj, cam_velo)
        # -----------------------------------------------

        time_taken = time.time() - start_time
        print('[%d/%d]  time: %.5f' % (i, total_batches, time_taken))

        if (i>0):
            total_time = total_time + time_taken

        # save seg image
        output = cam_output.cpu().data[0].numpy()  # 1xCxHxW ---> CxHxW
        output2 = imagery_output.cpu().data[0].numpy()  # 1xCxHxW ---> CxHxW
        # --------------softmax--------------------
        z_thr = np.asarray(np.argmax(output, axis=0), dtype=np.uint8)
        z_thr2 = np.asarray(np.argmax(output2, axis=0), dtype=np.uint8)
        # -------------------------------------
        z_fil2 = getLargestCC(z_thr)
        z_img2 = Image.fromarray(np.uint8(z_fil2[0:size[0], 0:size[1]]) * 255)
        z_img2.save("%s/%s" % (args.save_seg_dir, name[0]))

        z_fil2 = getLargestCC(z_thr2)
        z_img2 = Image.fromarray(np.uint8(z_fil2) * 255)
        if not os.path.exists(args.save_seg_dir + 'imagery'):
            os.makedirs(args.save_seg_dir + 'imagery')
        z_img2.save("%s/%s" % (args.save_seg_dir + 'imagery/', name[0]))

    avg_time = 1.0*total_time/(total_batches-1)
    print('average time: %.5f' % (avg_time))


def test_func(args):
    print(args)
    global network_type

    if args.cuda:
        print("=====> use gpu id: '{}'".format(args.gpus))
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus
        if not torch.cuda.is_available():
            raise Exception("no GPU found or wrong gpu id, please run without --cuda")


    model = TVFNet.TVFNet()
    network_type = "TVFNet"
    print("Arch:  TVFNet")

    if args.cuda:
        model = model.cuda()  # using GPU for inference
        cudnn.benchmark = True

    print('Dataset statistics')

    if args.save_seg_dir:
        if not os.path.exists(args.save_seg_dir):
            os.makedirs(args.save_seg_dir)

    # validation set
    testLoader = torch.utils.data.DataLoader(
        KittiRoadTestDataset(args.data_dir),
        batch_size=1, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    if args.resume:
        if os.path.isfile(args.resume):
            print("=====> loading checkpoint '{}'".format(args.resume))
            checkpoint = torch.load(args.resume)
            if torch.cuda.device_count() > 1:
                # multi GPUs used when training
                model.load_state_dict(convert_state_dict(checkpoint['model']))
            else:
                # only one GPU used when training
                model.load_state_dict(checkpoint['model'])
        else:
            print("=====> no checkpoint found at '{}'".format(args.resume))

    print("=====> beginning testing")
    print("test set length: ", len(testLoader))
    test(args, testLoader, model)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--model', default="TVFNet", help="model name: Two View Fusion based LiDAR Road Detection Network")
    parser.add_argument('--data_dir', default="/test/Road/data_road", help="data directory")
    parser.add_argument('--num_workers', type=int, default=1, help="the number of parallel threads")
    parser.add_argument('--batch_size', type=int, default=1,
                        help=" the batch_size is set to 1 when evaluating or testing")
    parser.add_argument('--resume', type=str, default="./checkpoint/kitti_road/TVFNet_bs16gpu0/model_best.pth",
                        help="use the file to load last checkpoint for evaluating or testing ")
    parser.add_argument('--cuda', default=True, help="run on CPU or GPU")
    parser.add_argument('--save_seg_dir', type=str, default="./result/kitti/test/",
                        help="saving path of prediction result")
    parser.add_argument("--gpus", default="0", type=str, help="gpu ids (default: 0)")

    test_func(parser.parse_args())

