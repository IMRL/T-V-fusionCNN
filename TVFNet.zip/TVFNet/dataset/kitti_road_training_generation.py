###########################################################################
# Created by: Shuo Gu
# Email: shuogu@njust.edu.cn
# Paper: Two-View Fusion based Convolutional Neural Network for Urban Road Detection, 2019 IROS
# Copyright (c) 2019
###########################################################################

# lidar data and gt in lidar imagery view + camera image view
# save in .npy files
# KITTI Road Training dataset

import numpy as np
from PIL import Image
from random import shuffle
import scipy.ndimage
import glob
import re
import os


def read_velo(file):
    scan = np.fromfile(file, dtype=np.float32)
    return scan.reshape((-1, 4))

# calculation of horizontal and vertical angles and range values
def velo2sph(xyz):  # x,y,z,intensity
    ptsnew = np.hstack((xyz, np.zeros((xyz.shape[0], 2))))
    xy = xyz[:, 0] ** 2 + xyz[:, 1] ** 2
    ptsnew[:, -2] = np.sqrt(xy) # x-y distance
    ptsnew[:, -1] = np.arctan2(xyz[:, 1], xyz[:, 0])  # azimuthal angle theta, horizontal angle
    return ptsnew

def read_calib_file(filepath):
    data = {}
    with open(filepath, 'r') as f:
        for line in f.readlines():
            try:
                key, value = line.split(':')
                # The only non-float values in these files are dates, which
                # we don't care about anyway
                data[key] = np.array([float(x) for x in value.split()])
            except ValueError:
                pass
    Tr_velo_to_cam = data['Tr_velo_to_cam'].reshape(3, 4)
    Tr_velo_to_cam = np.vstack((Tr_velo_to_cam, [0, 0, 0, 1]))
    R0_rect = data['R0_rect'].reshape(3, 3)
    T0_rect = np.vstack((np.hstack((R0_rect, (np.array([0, 0, 0])).reshape(3, 1))), [0, 0, 0, 1]))
    P2 = data['P2'].reshape(3, 4)
    P2 = np.vstack((P2, [0, 0, 0, 1]))
    Tr_velo_to_img = (P2.dot(T0_rect)).dot(Tr_velo_to_cam)
    Tr_velo_to_img = Tr_velo_to_img[0:3, :]
    return np.float32(Tr_velo_to_img)

# transform from LiDAR coordinate to camera coordinate
def Trans_velo_to_img(Tr_velo_to_img, velo):
    velo = np.transpose(velo)
    velo[3][:] = 1
    x = Tr_velo_to_img.dot(velo)
    x[0][:] = x[0][:] / x[2]
    x[1][:] = x[1][:] / x[2]
    return np.transpose(x)

# 3d lidar point to camera image view, 4 channels
def cam_data_generation(sph, Tr_velo_to_img):
    data = np.zeros([376, 1248, 4])
    depth = np.zeros([376, 1248])
    velo = np.ones([sph.shape[0], 4])
    velo[:, 0:3] = sph[:, 0:3]
    img_ij = Trans_velo_to_img(Tr_velo_to_img, velo)
    for i_pt in range(len(sph)):
        if (img_ij[i_pt][2] > 0):
            x = np.int(img_ij[0][0])
            y = np.int(img_ij[0][1])
            if (x >= 0 and x < 1248 and y >= 0 and y < 376):
                # save min depth
                if (depth[y, x] > 0 and depth[y, x] <= img_ij[i_pt][2]):
                    continue
                data[y, x, 0:4] = sph[i_pt, 0:4]
                depth[y, x] = img_ij[i_pt][2]
    return np.float32(data)

# camera image
def read_img(filepath):
    img = Image.open(filepath)
    img_arr = np.uint8(img)
    return img_arr

# road groundtruth 0, 1, 255
def read_gt(filepath):
    gt = Image.open(filepath)
    gt_arr = np.uint8(gt)
    gt_arr1 = gt_arr[:, :, 2] / 255
    gt_arr2 = -gt_arr[:, :, 0] + 255
    gt_arr = gt_arr1 + gt_arr2
    return gt_arr

# 3d lidar point to lidar imagery, 4 channels
def imagery_data_generation(sph, half_FOV=45):
    horizontal = 360
    data = np.zeros([64, horizontal * 4, 6])  # 360
    scan = 0
    num = 0
    for i_pt in range(len(sph)):
        x_shift_value = np.pi * 2 / horizontal
        if (sph[i_pt,0]<0):
            continue
        if (sph[i_pt,5]<0):
            num = num + 1
        if (i_pt>=1 and sph[i_pt-1,5]/x_shift_value<0 and sph[i_pt,5]/x_shift_value>=0 and num>100):
            num = 0
            scan = scan + 1
        column = np.ceil(-sph[i_pt,5]*4/x_shift_value + horizontal*2) # 360
        scan = np.int(scan)
        column = np.int(column)
        if (scan<0 or scan>=64 or column<0 or column>=horizontal*4): # 360
            continue
        if (data[scan,column,4]>0 and data[scan,column,4]<=sph[i_pt,4]):
            continue
        data[scan,column,0:6] = sph[i_pt,0:6]
    data_ = data[:,horizontal*2-half_FOV*4:horizontal*2+half_FOV*4,:]
    return np.float32(data_[:,:,0:4])

# road groundtruth in lidar imagery view according to gt in camera image, 0, 1, 255
def imagery_label_generation(data_sph, gt_img, Tr_velo_to_img):
    label = np.ones([data_sph.shape[0], data_sph.shape[1]]) * 255
    for i in range(data_sph.shape[0]):
        for j in range(data_sph.shape[1]):
            if (data_sph[i, j, 0] > 0):
                velo = np.zeros([1, 4])
                velo[0, 0:3] = data_sph[i, j, 0:3]
                img_ij = Trans_velo_to_img(Tr_velo_to_img, velo)
                x = np.int(img_ij[0][0])
                y = np.int(img_ij[0][1])
                if (x >= 0 and x < gt_img.shape[1] and y >= 0 and y < gt_img.shape[0]):
                    label[i, j] = gt_img[y, x]
    return label

# correspondences from lidar imagery to camera image, mimimum depth
def cor_imagery_cam(data_sph,Tr_velo_to_img,height=376,width=1248):
    mask = np.zeros([data_sph.shape[0],data_sph.shape[1]], dtype=np.int32)
    depth = np.zeros([height,width])
    index = np.zeros([height, width, 2])
    for i in range(data_sph.shape[0]):
        for j in range(data_sph.shape[1]):
            if (data_sph[i,j,0]>0):
                velo = np.zeros([1, 4])
                velo[0, 0:3] = data_sph[i, j, 0:3]
                img_ij = Trans_velo_to_img(Tr_velo_to_img, velo)
                x = np.int(img_ij[0][0])
                y = np.int(img_ij[0][1])
                if (x >= 0 and x < width and y >= 0 and y < height):
                    if (depth[y, x]>0 and depth[y, x]<=img_ij[0][2]):
                        continue
                    # remove the index in mask to ensure 1-to-1
                    if (depth[y, x] > 0):
                        mask[np.int(index[y,x,0]), np.int(index[y,x,1])] = 0
                    index[y,x,0] = i
                    index[y,x,1] = j
                    mask[i,j] = y*width+x
                    depth[y, x] = img_ij[0][2]
    return np.int32(mask)

# correspondences from lidar imagery to camera image, horizontal flip, minimum depth
def cor_imagery_cam2(data_sph,Tr_velo_to_img,height=376,width=1248):
    mask = np.zeros([data_sph.shape[0],data_sph.shape[1]], dtype=np.int32)
    depth = np.zeros([height,width])
    index = np.zeros([height, width, 2])
    for i in range(data_sph.shape[0]):
        for j in range(data_sph.shape[1]):
            if (data_sph[i,j,0]>0):
                velo = np.zeros([1, 4])
                velo[0, 0:3] = data_sph[i, j, 0:3]
                img_ij = Trans_velo_to_img(Tr_velo_to_img, velo)
                x = np.int(img_ij[0][0])
                x = width - 1 - x
                y = np.int(img_ij[0][1])
                if (x >= 0 and x < width and y >= 0 and y < height):
                    if (depth[y, x]>0 and depth[y, x]<=img_ij[0][2]):
                        continue
                    # remove the index in mask to ensure 1-to-1
                    if (depth[y, x] > 0):
                        mask[np.int(index[y, x, 0]), np.int(index[y, x, 1])] = 0
                    index[y, x, 0] = i
                    index[y, x, 1] = j
                    mask[i,j] = y*width+x
                    depth[y, x] = img_ij[0][2]
    return np.int32(mask)


# Raw Data directory information
basedir = '/test/Road/data_road/training'
velo_list = list(sorted(glob.iglob(basedir + '/velodyne/*.bin', recursive=True)))

list_shuffle=list(range(len(velo_list)*4))
shuffle(list_shuffle)

for i_sample in range(len(velo_list)):
    velo_name = velo_list[i_sample]
    words = velo_list[i_sample].replace('/', ' ').replace('_', ' ').replace('.', ' ').split()
    cam_name = basedir + '/image_2/' + words[-3] + '_' + words[-2] + '.png'
    calib_name = basedir + '/calib/' + words[-3] + '_' + words[-2] + '.txt'
    gt_name = basedir + '/gt_image_2/' + words[-3] + '_road_' + words[-2] + '.png'

    velo = read_velo(velo_name)
    sph = velo2sph(velo)
    Tr_velo_to_img = read_calib_file(calib_name)

    # camera
    cam_velo = cam_data_generation(sph, Tr_velo_to_img)
    cam_gt_or = read_gt(gt_name)
    cam_gt = np.ones([376, 1248]) * 255
    cam_gt[0:cam_gt_or.shape[0], 0:cam_gt_or.shape[1]] = cam_gt_or

    # lidar imagery
    imagery_velo = imagery_data_generation(sph)
    imagery_gt = imagery_label_generation(imagery_velo, cam_gt_or, Tr_velo_to_img) # 3 classes
    imagery_pj = cor_imagery_cam(imagery_velo, Tr_velo_to_img)
    imagery_pj_ = cor_imagery_cam2(imagery_velo, Tr_velo_to_img)

    name_list = ['cam_velo', 'cam_gt', 'imagery_velo', 'imagery_gt', 'imagery_pj']
    file_name = 'TVFNet'
    for i in range(len(name_list)):
        if not os.path.exists(basedir + '/' + file_name + '/' + name_list[i] + '/'):
            os.makedirs(basedir + '/' + file_name + '/' + name_list[i] + '/')

    np.save(basedir + '/' + file_name + '/' + name_list[0] + '/' + str(list_shuffle[i_sample * 4]).zfill(4) + '.npy', cam_velo)
    temp = Image.fromarray(np.uint8(cam_gt))
    temp.save(basedir + '/' + file_name + '/' + name_list[1] + '/' + str(list_shuffle[i_sample * 4]).zfill(4) + '.png', 'png')
    np.save(basedir + '/' + file_name + '/' + name_list[2] + '/' + str(list_shuffle[i_sample * 4]).zfill(4) + '.npy', imagery_velo)
    temp = Image.fromarray(np.uint8(imagery_gt))
    temp.save(basedir + '/' + file_name + '/' + name_list[3] + '/' + str(list_shuffle[i_sample * 4]).zfill(4) + '.png', 'png')
    np.save(basedir + '/' + file_name + '/' + name_list[4] + '/' + str(list_shuffle[i_sample * 4]).zfill(4) + '.npy', imagery_pj)


    np.save(basedir + '/' + file_name + '/' + name_list[0] + '/' + str(list_shuffle[i_sample * 4 + 1]).zfill(4) + '.npy', np.fliplr(cam_velo))
    temp = Image.fromarray(np.uint8(np.fliplr(cam_gt)))
    temp.save(basedir + '/' + file_name + '/' + name_list[1] + '/' + str(list_shuffle[i_sample * 4 + 1]).zfill(4) + '.png', 'png')
    np.save(basedir + '/' + file_name + '/' + name_list[2] + '/' + str(list_shuffle[i_sample * 4 + 1]).zfill(4) + '.npy', np.fliplr(imagery_velo))
    temp = Image.fromarray(np.uint8(np.fliplr(imagery_gt)))
    temp.save(basedir + '/' + file_name + '/' + name_list[3] + '/' + str(list_shuffle[i_sample * 4 + 1]).zfill(4) + '.png', 'png')
    np.save(basedir + '/' + file_name + '/' + name_list[4] + '/' + str(list_shuffle[i_sample * 4 + 1]).zfill(4) + '.npy', np.fliplr(imagery_pj_))


    np.save(basedir + '/' + file_name + '/' + name_list[0] + '/' + str(list_shuffle[i_sample * 4 + 2]).zfill(4) + '.npy', np.fliplr(cam_velo))
    temp = Image.fromarray(np.uint8(np.fliplr(cam_gt)))
    temp.save(basedir + '/' + file_name + '/' + name_list[1] + '/' + str(list_shuffle[i_sample * 4 + 2]).zfill(4) + '.png', 'png')
    np.save(basedir + '/' + file_name + '/' + name_list[2] + '/' + str(list_shuffle[i_sample * 4 + 2]).zfill(4) + '.npy', imagery_velo)
    temp = Image.fromarray(np.uint8(imagery_gt))
    temp.save(basedir + '/' + file_name + '/' + name_list[3] + '/' + str(list_shuffle[i_sample * 4 + 2]).zfill(4) + '.png', 'png')
    np.save(basedir + '/' + file_name + '/' + name_list[4] + '/' + str(list_shuffle[i_sample * 4 + 2]).zfill(4) + '.npy', imagery_pj_)


    np.save(basedir + '/' + file_name + '/' + name_list[0] + '/' + str(list_shuffle[i_sample * 4 + 3]).zfill(4) + '.npy', cam_velo)
    temp = Image.fromarray(np.uint8(cam_gt))
    temp.save(basedir + '/' + file_name + '/' + name_list[1] + '/' + str(list_shuffle[i_sample * 4 + 3]).zfill(4) + '.png', 'png')
    np.save(basedir + '/' + file_name + '/' + name_list[2] + '/' + str(list_shuffle[i_sample * 4 + 3]).zfill(4) + '.npy', np.fliplr(imagery_velo))
    temp = Image.fromarray(np.uint8(np.fliplr(imagery_gt)))
    temp.save(basedir + '/' + file_name + '/' + name_list[3] + '/' + str(list_shuffle[i_sample * 4 + 3]).zfill(4) + '.png', 'png')
    np.save(basedir + '/' + file_name + '/' + name_list[4] + '/' + str(list_shuffle[i_sample * 4 + 3]).zfill(4) + '.npy', np.fliplr(imagery_pj))