###########################################################################
# Created by: Shuo Gu
# Email: shuogu@njust.edu.cn
# Paper: Two-View Fusion based Convolutional Neural Network for Urban Road Detection, 2019 IROS
# Copyright (c) 2019
###########################################################################

import torch
import os
import os.path as osp
import numpy as np
import random
import matplotlib.pyplot as plt
import collections
import torchvision
import cv2
from torch.utils import data
import pickle
from PIL import Image
import glob
import time


class KittiRoadDataset(data.Dataset):
    def __init__(self, root='/home/data/KITTI/Road/data_road', ignore_label=255):
        self.root = root
        self.ignore_label = ignore_label
        self.length = 1040

        data_list = list(sorted(glob.iglob(root + '/training/TVFNet/cam_velo/*.npy', recursive=True)))
        self.files = []
        for i_sample in range(self.length):
            self.files.append({"name": data_list[i_sample]})

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        datafiles = self.files[index]

        words = datafiles["name"].replace('/', ' ').replace('_', ' ').replace('.', ' ').split()
        imagery_velo_name = self.root + '/training/TVFNet/imagery_velo/' + words[-2] + '.npy'
        imagery_gt_name = self.root + '/training/TVFNet/imagery_gt/' + words[-2] + '.png'
        imagery_pj_name = self.root + '/training/TVFNet/imagery_pj/' + words[-2] + '.npy'
        cam_velo_name = datafiles["name"]
        cam_gt_name = self.root + '/training/TVFNet/cam_gt/' + words[-2] + '.png'

        imagery_velo = np.load(imagery_velo_name)
        imagery_pj = np.load(imagery_pj_name)
        imagery_gt = np.array(Image.open(imagery_gt_name))
        cam_velo = np.load(cam_velo_name)
        cam_gt = np.array(Image.open(cam_gt_name))

        # b x c x h x w
        imagery_velo = imagery_velo.transpose((2, 0, 1))
        cam_velo = cam_velo.transpose((2, 0, 1))

        return imagery_velo.copy(), imagery_pj.copy(), imagery_gt.copy(), \
               cam_velo.copy(), cam_gt.copy()

class KittiRoadValDataset(data.Dataset):
    def __init__(self, root='/home/data/KITTI/Road/data_road', ignore_label=255):
        self.root = root
        self.ignore_label = ignore_label
        self.length = 116

        data_list = list(sorted(glob.iglob(root + '/training/TVFNet/cam_velo/*.npy', recursive=True)))
        self.files = []
        for i_sample in range(self.length):
            self.files.append({"name": data_list[i_sample+1040]})

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        datafiles = self.files[index]

        words = datafiles["name"].replace('/', ' ').replace('_', ' ').replace('.', ' ').split()
        imagery_velo_name = self.root + '/training/TVFNet/imagery_velo/' + words[-2] + '.npy'
        imagery_gt_name = self.root + '/training/TVFNet/imagery_gt/' + words[-2] + '.png'
        imagery_pj_name = self.root + '/training/TVFNet/imagery_pj/' + words[-2] + '.npy'
        cam_velo_name = datafiles["name"]
        cam_gt_name = self.root + '/training/TVFNet/cam_gt/' + words[-2] + '.png' # 3 classes

        imagery_velo = np.load(imagery_velo_name)
        imagery_pj = np.load(imagery_pj_name)
        imagery_gt = np.array(Image.open(imagery_gt_name))
        cam_velo = np.load(cam_velo_name)
        cam_gt = np.array(Image.open(cam_gt_name))

        # b x c x h x w
        imagery_velo = imagery_velo.transpose((2, 0, 1))
        cam_velo = cam_velo.transpose((2, 0, 1))

        return imagery_velo.copy(), imagery_pj.copy(), imagery_gt.copy(), \
               cam_velo.copy(), cam_gt.copy()

class KittiRoadTestDataset(data.Dataset):
    def __init__(self, root='/home/data/KITTI/Road/data_road', ignore_label=255):
        self.root = root
        self.ignore_label = ignore_label
        self.img_ids = glob.glob(os.path.join((self.root).strip() + '/testing/TVFNet/cam_velo/*.npy'))
        self.files = []
        for name in self.img_ids:
            self.files.append({
                "name": name
            })
        print("lenth of dataset: ", len(self.files))

    def __len__(self):
        return len(self.files)

    def __getitem__(self, index):
        datafiles = self.files[index]

        words = datafiles["name"].replace('/', ' ').replace('_', ' ').replace('.', ' ').split()
        name = words[-3] + '_road_' + words[-2] + '.png'

        image_name = self.root + '/testing/image_2/' + words[-3] + '_' + words[-2] + '.png'
        image = cv2.imread(image_name, cv2.IMREAD_COLOR)
        size = image.shape

        imagery_velo_name = self.root + '/testing/TVFNet/imagery_velo/' + words[-3] + '_' + words[-2] + '.npy'
        imagery_pj_name = self.root + '/testing/TVFNet/imagery_pj/' + words[-3] + '_' + words[-2] + '.npy'
        cam_velo_name = datafiles["name"]

        imagery_velo = np.load(imagery_velo_name)
        imagery_pj = np.load(imagery_pj_name)
        cam_velo = np.load(cam_velo_name)

        # b x c x h x w
        imagery_velo = imagery_velo.transpose((2, 0, 1))
        cam_velo = cam_velo.transpose((2, 0, 1))

        return imagery_velo.copy(), imagery_pj.copy(), cam_velo.copy(), name, size