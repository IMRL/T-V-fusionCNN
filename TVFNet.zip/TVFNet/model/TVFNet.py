###########################################################################
# Created by: Shuo Gu
# Email: shuogu@njust.edu.cn
# Paper: Two-View Fusion based Convolutional Neural Network for Urban Road Detection, 2019 IROS
# Copyright (c) 2019
###########################################################################

import torch
import torch.nn as nn
import torch.nn.functional as F


class Conv(nn.Module):
    def __init__(self, nIn, nOut, kSize, stride=(1,1)):
        super().__init__()
        padding = int((kSize - 1)/2)
        self.conv = nn.Conv2d(nIn, nOut, (kSize, kSize), stride=stride, padding=(padding, padding), bias=False)

    def forward(self, input):
        output = self.conv(input)
        return output

class ConvBNELU(nn.Module):
    def __init__(self, nIn, nOut, kSize, stride=(1,1)):
        super().__init__()
        padding = int((kSize - 1)/2)
        self.conv = nn.Conv2d(nIn, nOut, (kSize, kSize), stride=stride, padding=(padding, padding), bias=False)
        self.bn = nn.BatchNorm2d(nOut, eps=1e-03)
        self.act = nn.ELU(nOut)

    def forward(self, input):
        output = self.conv(input)
        output = self.bn(output)
        output = self.act(output)
        return output

class DilatedConvBNELUDrop(nn.Module):
    def __init__(self, nIn, nOut, kSize, stride=(1,1), dilation=(1,1)):
        super().__init__()
        padding = (int((kSize - 1) / 2) * dilation[0], int((kSize - 1) / 2) * dilation[1])
        self.conv = nn.Conv2d(nIn, nOut, (kSize, kSize), stride=stride, padding=padding,
                              dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(nOut, eps=1e-03)
        self.act = nn.ELU(nOut)
        self.drop = nn.Dropout2d(p=0.25)

    def forward(self, input):
        output = self.conv(input)
        output = self.bn(output)
        output = self.act(output)
        output = self.drop(output)
        return output

class DeconvBNELU(nn.Module):
    def __init__(self, nIn, nOut, kSize, stride=(1,1), output_padding=(0,0), dilation=(1,1)):
        super().__init__()
        padding = (int((kSize - 1) / 2) * dilation[0], int((kSize - 1) / 2) * dilation[1])
        self.dconv = nn.ConvTranspose2d(nIn, nOut, (kSize, kSize), stride=stride, padding=padding,
                                        output_padding=output_padding, bias=False, dilation=dilation)
        self.bn = nn.BatchNorm2d(nOut, eps=1e-03)
        self.act = nn.ELU(nOut)

    def forward(self, input):
        output = self.dconv(input)
        output = self.bn(output)
        output = self.act(output)
        return output

class ContextBlock(nn.Module):
    def __init__(self, nIn):
        super().__init__()
        self.dilated_conv1 = DilatedConvBNELUDrop(nIn, nIn, 3, dilation=(1, 1))
        self.dilated_conv2 = DilatedConvBNELUDrop(nIn, nIn, 3, dilation=(1, 2))
        self.dilated_conv4 = DilatedConvBNELUDrop(nIn, nIn, 3, dilation=(2, 4))
        self.dilated_conv8 = DilatedConvBNELUDrop(nIn, nIn, 3, dilation=(4, 8))
        self.dilated_conv16 = DilatedConvBNELUDrop(nIn, nIn, 3, dilation=(8, 16))
        self.dilated_conv32 = DilatedConvBNELUDrop(nIn, nIn, 3, dilation=(16, 32))
        self.dilated_conv1_ = DilatedConvBNELUDrop(nIn, nIn, 3, dilation=(1, 1))

        self.conv = Conv(nIn, nIn, 1)

    def forward(self, input):
        output = self.dilated_conv1(input)
        output = self.dilated_conv2(output)
        output = self.dilated_conv4(output)
        output = self.dilated_conv8(output)
        output = self.dilated_conv16(output)
        output = self.dilated_conv32(output)
        output = self.dilated_conv1_(output)

        output = self.conv(output)

        return output

class Encoder_imagery(nn.Module):
    def __init__(self, nIn, nOut):
        super().__init__()
        self.conv1 = ConvBNELU(nIn, nOut, 3)
        self.conv2 = ConvBNELU(nOut, nOut, 3)
        self.conv3 = ConvBNELU(nOut, nOut*2, 3, (1,2))
        self.conv4 = ConvBNELU(nOut*2, nOut*2, 3)
        self.conv5 = ConvBNELU(nOut*2, nOut*4, 3, (2,2))

    def forward(self, input):
        output = self.conv1(input)
        output = self.conv2(output)
        skip1 = output

        output = self.conv3(output)
        output = self.conv4(output)
        skip2 = output

        output = self.conv5(output)
        skip3 = output

        return output, skip1, skip2, skip3

class Decoder_imagery(nn.Module):
    def __init__(self, nIn, nOut, channel=4, nclass=2):
        super().__init__()
        self.dconv1 = DeconvBNELU(nIn, nOut, 3, (2,2), (1,1))
        self.conv1 = ConvBNELU(nOut, nOut, 3)
        self.dconv2 = DeconvBNELU(nOut, int(nOut/2), 3, (1,2), (0,1))
        self.conv2 = ConvBNELU(int(nOut / 2), channel, 3)
        self.conv3 = Conv(channel, nclass, 3)

    def forward(self, input, skip1, skip2, skip3):
        output = skip3 + input
        output = self.dconv1(output)
        output = self.conv1(output)

        output = skip2 + output
        output = self.dconv2(output)

        output = skip1 + output
        output1 = self.conv2(output)
        output2 = self.conv3(output1)

        return output1, output2

class Encoder_cam(nn.Module):
    def __init__(self, nIn, nOut):
        super().__init__()
        self.conv1 = ConvBNELU(nIn, nOut, 3, (2,2))
        self.conv2 = ConvBNELU(nOut, nOut, 3)
        self.conv3 = ConvBNELU(nOut, nOut*2, 3, (2,2))
        self.conv4 = ConvBNELU(nOut*2, nOut*2, 3)
        self.conv5 = ConvBNELU(nOut*2, nOut*4, 3, (2,2))

    def forward(self, input):
        output = self.conv1(input)
        output = self.conv2(output)
        skip1 = output

        output = self.conv3(output)
        output = self.conv4(output)
        skip2 = output

        output = self.conv5(output)
        skip3 = output

        return output, skip1, skip2, skip3

class Decoder_cam(nn.Module):
    def __init__(self, nIn, nOut, nclass=2):
        super().__init__()
        self.dconv1 = DeconvBNELU(nIn, nOut, 3, (2,2), (1,1))
        self.conv1 = ConvBNELU(nOut, nOut, 3)
        self.dconv2 = DeconvBNELU(nOut, int(nOut/2), 3, (2,2), (1,1))
        self.conv2 = ConvBNELU(int(nOut/2), int(nOut/2), 3)
        self.dconv3 = DeconvBNELU(int(nOut/2), 8, 3, (2,2), (1,1))
        self.conv3 = Conv(8, nclass, 3)

    def forward(self, input, skip1, skip2, skip3):
        output = skip3 + input
        output = self.dconv1(output)
        output = self.conv1(output)

        output = skip2 + output
        output = self.dconv2(output)
        output = self.conv2(output)

        output = skip1 + output
        output = self.dconv3(output)
        output = self.conv3(output)

        return output

class ImageryToPers(nn.Module):
    def __init__(self, height=376, width=1248):
        super().__init__()
        self.height = height
        self.width = width

    def forward(self, input, pj):
        input_on_grad = input.detach()
        data_flat = input_on_grad.view(input_on_grad.shape[0], input_on_grad.shape[1], -1)
        mask_flat = pj.view(pj.shape[0], 1, -1)
        cam_flat = torch.zeros(input_on_grad.shape[0], input_on_grad.shape[1], self.height * self.width).cuda()

        final_data_flat_ = cam_flat.scatter(2, mask_flat, data_flat)

        output = final_data_flat_.view(input_on_grad.shape[0], input_on_grad.shape[1], self.height, self.width)

        return output

class TVFNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder_imagery = Encoder_imagery(4, 32)
        self.context = ContextBlock(128)
        self.decoder_imagery = Decoder_imagery(128, 64)

        self.encoder_cam = Encoder_cam(8, 32)
        self.context2 = ContextBlock(128)
        self.decoder_cam = Decoder_cam(128, 64)

        self.imagery_to_pers = ImageryToPers()

        # init weights
        for m in self.modules():
            classname = m.__class__.__name__
            if classname.find('Conv2d') != -1:
                nn.init.kaiming_normal_(m.weight)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif classname.find('ConvTranspose2d') != -1:
                nn.init.kaiming_normal_(m.weight)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif classname.find('BatchNorm2d') != -1:
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()

    def forward(self, imagery_velo, imagery_pj, cam_velo):

        # lidar imagery view
        x, skip1, skip2, skip3 = self.encoder_imagery(imagery_velo)
        x = self.context(x)
        x, x1 = self.decoder_imagery(x, skip1, skip2, skip3)

        y = self.imagery_to_pers(x, imagery_pj)

        # camera perspective view
        x = torch.cat([y, cam_velo], 1)
        x, skip1, skip2, skip3 = self.encoder_cam(x)
        x = self.context(x)
        x2 = self.decoder_cam(x, skip1, skip2, skip3)

        return x1, x2