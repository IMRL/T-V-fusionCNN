###########################################################################
# Created by: Shuo Gu
# Email: shuogu@njust.edu.cn
# Paper: Two-View Fusion based Convolutional Neural Network for Urban Road Detection, 2019 IROS
# Copyright (c) 2019
###########################################################################

import torch
import torch.nn as nn


class CrossEntropyLoss2d(nn.Module):
    def __init__(self):
        super().__init__()
        self.loss = nn.CrossEntropyLoss(ignore_index=255)
    def forward(self, outputs1, outputs2, targets1, targets2):
        loss1 = self.loss(outputs1, targets1)
        loss2 = self.loss(outputs2, targets2)
        loss = loss1 + loss2

        return loss, loss1, loss2